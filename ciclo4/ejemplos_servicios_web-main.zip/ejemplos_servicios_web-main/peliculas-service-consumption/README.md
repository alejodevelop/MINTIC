# peliculas-service-consumption

## Documentación
[The Movie DB documentación](https://developers.themoviedb.org/3/getting-started/introduction)
## Enpoint
Para este template se utilizara el endpoint: **/trending/movie/day**.
> obtiene los items(paliculas/series) que se encuentran trending durante el dia
## Acceso a la API
Se require una ApiKey para la autenticación, esta se puede solicitar creando una cuenta de [The Movie DB](https://www.themoviedb.org/signup) para obtener una ApiKey se debe ir a la sección API en la configuración(settings) de la cuenta.
## Limites API
not limits
