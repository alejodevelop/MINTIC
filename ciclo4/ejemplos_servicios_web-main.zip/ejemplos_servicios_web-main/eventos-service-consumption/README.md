# eventos-service-consumption

## Documentación
[The SeatGeek Platform documentación](https://platform.seatgeek.com/)
## Enpoint
Para este template se utilizara el endpoint: **/events**.
> Obtiene una lista de eventos
## Acceso a la API
Para Acceder a la API se requiere de autenticaión por ApiKey, se puede solicitar uno una vez creada una cuenta en [The SeatGeek Platform](https://seatgeek.com/account/develop), se debe crear una app y esta genera un **Client ID** el cual se puede utilizar para autenticarse.
## Limites API
No se especificaron limites en el numero de peticiones que se pueden realizar.
