# arte-2-service-consumption

## Documentación
[Rijksmuseum documentación](https://data.rijksmuseum.nl/object-metadata/api/)
## Enpoint
Para este template se utilizara el endpoint: **/collection**.
> Obtiene una lista de los elementos en la collecion del museo
## Acceso a la API
Esta API requiere de una ApiKey, para esto se debe crear una cuenta de Rijksstudio registrarse [aqui](https://www.rijksmuseum.nl/en/rijksstudio).
Se puede solicitar una ApiKey una vez confirmado el correo, en los ajustes avanzados de la cuenta de Rijksstudio.
## Limites API
No se especifican limites de las peticiones en la documentación.
