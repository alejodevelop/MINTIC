# anime-service-consumption

## Documentación
[kitsu documentación](https://kitsu.docs.apiary.io/#)
## Enpoint
Para este template se utilizara el endpoint: **/edge/anime**.
> Obtiene una lista de animes
## Acceso a la API
Esta API no require autenticación, se puede acceder de forma libre.
## Limites API
not limits