# musica-service-consumption

## Documentación
[napster documentación](https://developer.napster.com/api/v2.2)
## Enpoint
Para este template se utilizara el endpoint: **/tracks/top**.
> Obtiene una lista de tracks que se encuentran en el top
## Acceso a la API
La autenticación de la API es por medio de ApiKey, se puede obtener una ApiKey al crear una app en la plataforma de [napster](https://developer.napster.com/signin) para desarrolladores.
## Limites API
5 calls/ second
