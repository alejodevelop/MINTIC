# trading-2-service-consumption

## Documentación
[CryptingUp documentación](https://www.cryptingup.com/apidoc/#introduction)
## Enpoint
Para este template se utilizara el endpoint: **/assets**.
> Obtiene todos los assets con paginacion
## Acceso a la API
Esta API no require autenticación, se puede acceder de forma libre.
## Limites API
not limits