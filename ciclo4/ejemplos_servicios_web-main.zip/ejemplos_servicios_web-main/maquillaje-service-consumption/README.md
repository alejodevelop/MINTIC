# maquillaje-service-consumption

## Documentación
[MakeUpAPI documentación](http://makeup-api.herokuapp.com/)
## Enpoint
Para este template se utilizara el endpoint: **/products.json**.
> Obitene una lista de productos de maquillaje
## Acceso a la API
Esta API no require autenticación, se puede acceder de forma libre.
## Limites API
not limits