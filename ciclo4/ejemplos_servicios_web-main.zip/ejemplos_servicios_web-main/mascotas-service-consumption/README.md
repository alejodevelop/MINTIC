# mascotas-service-consumption

## Documentación
[RescueGroups documentación](https://userguide.rescuegroups.org/display/APIDG/API+Developers+Guide+Home)
## Enpoint
Para este template se utilizara el endpoint: **/public/animals**.
> Obtiene una lista de animales en los registros publicos de adopcion
## Acceso a la API
Se require una ApiKey para acceder a la API, esta se puede solicitar llenando el siguiente [formulario](https://rescuegroups.org/services/request-an-api-key/), tener en cuenta lo que dice en la sección de [**Educational Purposes**](https://rescuegroups.org/api-terms-of-service/) en los termicons y condiciones de la API. 
## Limites API
No se especificaron limites al numero de peticiones que se puenden realizar.
