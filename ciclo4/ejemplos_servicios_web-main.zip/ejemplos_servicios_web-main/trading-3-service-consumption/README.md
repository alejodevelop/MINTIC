# trading-3-service-consumption

## Documentación
[Coinpaprika documentación](https://api.coinpaprika.com/)
## Enpoint
Para este template se utilizara el endpoint: **/exchanges**.
> Obtiene una lista de los exchanges de cryptomonedas
## Acceso a la API
Esta API no require autenticación, se puede acceder de forma libre.
## Limites API
10 calls/ second