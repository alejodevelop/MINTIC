# conservacion-service-consumption

## Documentación
[IUCN Red list of threatened species documentación](http://apiv3.iucnredlist.org/api/v3/docs)
## Enpoint
Para este template se utilizara el endpoint: **/species/page/0**.
> Obtiene una lista de especies en la base de datos de especies en peligro de extincion
## Acceso a la API
Esta API requirede de autenticación por ApiKey, para solicitar una se debe llenar el siguiente [formulario](http://apiv3.iucnredlist.org/api/v3/token), tener en cuenta no marcar el checkbox que indica que se usara la API con fines comerciales y explicar detalladamente que se trata de un proyecto con fines educativos.
## Limites API
En la documentacion no se especificaron limitantes al numero de peticiones que se pueden hacer.
