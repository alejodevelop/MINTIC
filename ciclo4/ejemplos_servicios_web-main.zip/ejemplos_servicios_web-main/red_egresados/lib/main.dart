import 'package:flutter/material.dart';
import 'package:red_egresados/ui/app.dart';

void main() {
  runApp(const App());
}
