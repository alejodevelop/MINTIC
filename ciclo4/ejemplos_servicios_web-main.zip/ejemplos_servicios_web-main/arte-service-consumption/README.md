# arte-service-consumption

## Documentación
[Art Institute of Chicago documentación](https://api.artic.edu/docs/)
## Enpoint
Para este template se utilizara el endpoint: **/artworks**.
> Obtiene una lista de trabajos de arte en la coleccion del museo de arte de Chicago
## Acceso a la API
Esta API no require autenticación, se puede acceder de forma libre.
## Limites API
not limits