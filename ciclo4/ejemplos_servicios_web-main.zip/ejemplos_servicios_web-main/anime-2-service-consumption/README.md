# anime-2-service-consumption

## Documentación
[Jikan documentación](
https://jikan.docs.apiary.io/#)
## Enpoint
Para este template se utilizara el endpoint: **/top/anime/1/upcoming**.
> Obtiene una lista de los animes mas esperados en la pagina de MyAnimeLIst
## Acceso a la API
Esta API no require autenticación, se puede acceder de forma libre.
## Limites API
30 requests / minute
2 requests / second